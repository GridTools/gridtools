Gridtools4py

Python bindings/interpreter for the C++ Gridtools library


INSTALLATION

Use CMake to install it, selecting the USE_PYTHON option.-
